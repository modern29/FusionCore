# Lobby Guardian v4.3.35 — All-player Join / Leave Alerts

**Status:** Consolidated GitHub Actions source candidate, not a precompiled APK. Join/leave notifications need an Android game build and in-lobby testing.

## New feature
- In **LG+ → Information → Player Join / Leave Alerts**: toggle join and leave messages for **all other players**, whether you are host or guest.
- Shows a short banner like “Player123 joined the lobby” or “Player123 left the lobby.” Multiple alerts are stacked (up to 4) and shown for **6 seconds by default**, adjustable from **3 to 12 seconds**.
- Monitors publicly visible lobby names on your game client. No server-side privileged access, friend codes, PUIDs or player account secrets are collected or transmitted.
- Initializes silently when you first join a lobby; after that, captures new joins and departures, with a short missing-player confirmation to avoid false notifications during loading. Existing watched-player and Bot Shield features are untouched.
- Alerts are enabled by default; you can turn them off in the Feature Hub.
- Native Android preview button shows a sample alert for UI testing.

## Build from Android
1. Upload `lobbyguardian-v4335-join-leave-notifications-combined-android.yml` to `.github/workflows/` in `modern29/FusionCore`.
2. Commit. GitHub Actions should run automatically; otherwise select Run workflow.
3. Wait for a successful workflow run and download the artifact **LobbyGuardian-v4.3.35-Android-JoinLeave-Combined**. If the build fails, inspect its error log; an APK is not guaranteed by the workflow file alone.
4. Open a lobby with friends. Enable **Join / Leave Alerts** and confirm every entrant and departure shows a six-second banner; test as host and nonhost.

## Preserved features and limits
Contains v4.3.34 source: DM, noclip, radar, click TP, ESP/freecam implementation attempts, Copy Player Look, Follow Player, drawing/text composers, host tools, Bot Shield, and optional Community Relay source. No replay or music player. Previous versions were not fully compiled or validated, and many original SickoMenu/Nocturne features remain outside the implementation. Do not assume all controls work until verified on a device.

## Community Relay reminder
`LobbyGuardian-Community-Relay-v0.1.zip` is included. It still needs your Cloudflare Worker setup, database, and explicit opt-in; it is not deployed by installing the APK.
