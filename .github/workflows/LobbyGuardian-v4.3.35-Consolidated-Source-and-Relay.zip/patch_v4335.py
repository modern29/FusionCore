from pathlib import Path
p=Path('LobbyGuardian/Plugin')
j=Path('fusionApp/src/main/java/dev/allofus/fusioncore')
plugin=p/'LobbyGuardianPlugin.cs'
ui=j/'FeatureHubPanel.java'
assert plugin.is_file() and ui.is_file()
def once(path,old,new):
    content=path.read_text()
    assert content.count(old)==1, (path.name,old,content.count(old))
    path.write_text(content.replace(old,new,1))
once(plugin,'            FeatureHubNocturnePort.Tick();',
    '            FeatureHubNocturnePort.Tick();\n            LobbyPresenceAlerts.Tick();')
once(ui,'VoteRemovalWatchPanel.start(a);',
    'VoteRemovalWatchPanel.start(a);LobbyPresenceAlertPanel.attach(a);')
anchor='            row(a,rows,"Information","Spatial data & role labels","distance ghost vents roles",()->{'
row='''            row(a,rows,"Information","Player Join / Leave Alerts","all players join leave notifications host non host duration toggle",()->LobbyPresenceAlertPanel.configure(a),s,c);
'''
once(ui,anchor,row+anchor)
assert 'LobbyPresenceAlerts.Tick();' in plugin.read_text()
assert 'LobbyPresenceAlertPanel.attach(a);' in ui.read_text()
assert 'TryTargetedDm' in (p/'WhisperRelay.cs').read_text()
assert 'Replay' not in ui.read_text()
print('v4.3.35: all-player join/leave monitor and Android notification UI integrated. Existing DM and noclip untouched.')
