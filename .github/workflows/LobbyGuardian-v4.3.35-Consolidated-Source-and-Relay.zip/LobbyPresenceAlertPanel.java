package dev.allofus.fusioncore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** On-screen announcements for ordinary lobby joins/leaves, including non-host lobbies. */
public final class LobbyPresenceAlertPanel {
    private LobbyPresenceAlertPanel(){}
    private static final String OPTIONS="LobbyGuardian-feature-options.json";
    private static final String EVENTS="LobbyGuardian-presence-events.json";
    private static final String TAG="LG_PRESENCE_ALERTS_V4335";
    private static final Handler HANDLER=new Handler(Looper.getMainLooper());
    private static Activity active;
    private static LinearLayout display;
    private static Runnable poll;
    private static String session="";
    private static int seen=0;
    private static int cap=0;
    private static int dp(Activity a,int px){return (int)(px*a.getResources().getDisplayMetrics().density+.5f);}
    private static File config(Activity a){
        File root=a.getFilesDir(),p=root.getParentFile();
        File[] folders={new File(root,"BepInEx/config"),new File(p,"BepInEx/config"),
            new File(p,"files/BepInEx/config"),new File(root,"config"),
            a.getExternalFilesDir(null)==null?root:new File(a.getExternalFilesDir(null),"BepInEx/config")};
        for(File f:folders)if(new File(f,"LobbyGuardian-feature-status.json").exists()||
            new File(f,"LobbyGuardian-utility-options.json").exists()||new File(f,EVENTS).exists())return f;
        for(File f:folders)if(f.isDirectory()&&"config".equals(f.getName()))return f;
        return new File(root,"BepInEx/config");
    }
    private static JSONObject read(File file){try(FileInputStream in=new FileInputStream(file)){
        byte[] bytes=new byte[(int)Math.min(20000,file.length())];int n=in.read(bytes);
        if(n<1)return new JSONObject();
        return new JSONObject(new String(bytes,0,n,StandardCharsets.UTF_8));
    }catch(Exception ignored){return new JSONObject();}}
    private static JSONObject options(Activity a){return read(new File(config(a),OPTIONS));}
    private static boolean enabled(Activity a){return options(a).optBoolean("JoinLeaveAlertsEnabled",true);}
    private static int duration(Activity a){return Math.max(3,Math.min(12,options(a).optInt("JoinLeaveAlertDurationSeconds",6)));}
    private static void save(Activity a,boolean on,int seconds){try{
        File f=new File(config(a),OPTIONS);JSONObject o=read(f);
        o.put("JoinLeaveAlertsEnabled",on);
        o.put("JoinLeaveAlertDurationSeconds",seconds);
        File folder=f.getParentFile();if(folder!=null)folder.mkdirs();
        try(FileOutputStream out=new FileOutputStream(f,false)){out.write(o.toString().getBytes(StandardCharsets.UTF_8));}
    }catch(Exception e){Toast.makeText(a,"Unable to save join/leave settings",Toast.LENGTH_LONG).show();}}
    public static void attach(Activity a){a.runOnUiThread(()->{
        if(a.isFinishing()||a.isDestroyed())return;
        if(a==active&&poll!=null)return;
        if(poll!=null)HANDLER.removeCallbacks(poll);
        active=a;session="";seen=0;
        FrameLayout root=a.findViewById(android.R.id.content);if(root==null)return;
        View existing=root.findViewWithTag(TAG);
        if(existing instanceof LinearLayout)display=(LinearLayout)existing;
        else{
            display=new LinearLayout(a);display.setOrientation(LinearLayout.VERTICAL);display.setTag(TAG);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(a,290),-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            lp.topMargin=dp(a,78);root.addView(display,lp);
        }
        poll=new Runnable(){@Override public void run(){
            if(a.isFinishing()||a.isDestroyed()||a!=active)return;
            try{check(a);}catch(Exception ignored){}
            HANDLER.postDelayed(this,700);
        }};
        HANDLER.postDelayed(poll,300);
    });}
    private static void check(Activity a){
        JSONObject data=read(new File(config(a),EVENTS));
        String newSession=data.optString("session","");
        if(newSession.isEmpty())return;
        int latest=data.optInt("lastSeq",0);
        // Don't replay previously-recorded events when opening the app or entering a fresh session.
        if(!newSession.equals(session)){session=newSession;seen=latest;return;}
        if(!enabled(a)){seen=latest;return;}
        JSONArray events=data.optJSONArray("events");
        if(events!=null)for(int i=0;i<events.length();i++){
            JSONObject e=events.optJSONObject(i);if(e==null)continue;
            int seq=e.optInt("seq",0);if(seq<=seen)continue;
            String kind=e.optString("kind","");
            String name=e.optString("name","").trim();
            if(name.isEmpty()||(!kind.equals("join")&&!kind.equals("leave")))continue;
            announce(a,kind,name);
        }
        seen=Math.max(seen,latest);
    }
    private static void announce(Activity a,String kind,String name){
        if(display==null)return;
        final TextView text=new TextView(a);
        boolean join=kind.equals("join");
        text.setText((join?"\u25cf  ":"\u25cb  ")+name+(join?" joined the lobby":" left the lobby"));
        text.setTextColor(Color.WHITE);text.setTextSize(14);text.setMaxLines(2);
        text.setPadding(dp(a,12),dp(a,10),dp(a,10),dp(a,10));
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(0xf11a2332);bg.setCornerRadius(dp(a,11));bg.setStroke(dp(a,2),join?0xff56c99c:0xffffa777);
        text.setBackground(bg);text.setElevation(dp(a,5));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(a,5);
        display.addView(text,0,p);
        while(display.getChildCount()>4)display.removeViewAt(display.getChildCount()-1);
        HANDLER.postDelayed(()->{if(text.getParent()==display)display.removeView(text);},duration(a)*1000L);
    }
    public static void configure(Activity a){a.runOnUiThread(()->{
        JSONObject data=options(a);
        LinearLayout frame=new LinearLayout(a);frame.setOrientation(LinearLayout.VERTICAL);
        frame.setPadding(dp(a,18),dp(a,8),dp(a,18),dp(a,4));
        CheckBox on=new CheckBox(a);on.setText("Show every player's join/leave notifications");
        on.setChecked(enabled(a));frame.addView(on);
        TextView seconds=new TextView(a);seconds.setTextColor(Color.DKGRAY);seconds.setText("Keep alert visible: "+duration(a)+" seconds");
        frame.addView(seconds);
        SeekBar seek=new SeekBar(a);seek.setMax(9);seek.setProgress(duration(a)-3);frame.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar v,int n,boolean user){seconds.setText("Keep alert visible: "+(n+3)+" seconds");}
            public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
        });
        new AlertDialog.Builder(a).setTitle("Player join / leave alerts")
            .setMessage("Shows player names when anyone joins or leaves your current lobby. Works as host or guest. No remote messages are sent.")
            .setView(frame).setNegativeButton("Cancel",null)
            .setNeutralButton("Preview",(d,w)->announce(a,"join","ExamplePlayer"))
            .setPositiveButton("Save",(d,w)->{
                save(a,on.isChecked(),seek.getProgress()+3);
                Toast.makeText(a,on.isChecked()?"Player alerts ON":"Player alerts OFF",Toast.LENGTH_SHORT).show();
            }).show();
    });}
}
