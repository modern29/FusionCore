using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using BepInEx;

namespace LobbyGuardian;

/// <summary>Read-only, local join/leave observer. Works regardless of host status.</summary>
internal static class LobbyPresenceAlerts
{
    private const BindingFlags Flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
    private static readonly string InstanceId=Guid.NewGuid().ToString("N");
    private static readonly Dictionary<string,string> Current=new(StringComparer.Ordinal);
    private static readonly Dictionary<string,int> Missing=new(StringComparer.Ordinal);
    private static readonly List<object> Events=new();
    private static DateTimeOffset _next=DateTimeOffset.MinValue;
    private static string _room="",_source="";
    private static bool _initialized;
    private static int _sequence;
    private static string At(string name)=>Path.Combine(Paths.ConfigPath,name);
    private static Type? TypeOf(string name)
    {
        foreach(var asm in AppDomain.CurrentDomain.GetAssemblies())
            try{var type=asm.GetType(name,false);if(type!=null)return type;}catch{}
        return null;
    }
    private static object? Get(object? obj,params string[] names)
    {
        if(obj==null)return null;
        Type t=obj is Type type?type:obj.GetType();object? instance=obj is Type?null:obj;
        foreach(var name in names)
        for(Type? walk=t;walk!=null;walk=walk.BaseType)
        {
            try{var value=walk.GetProperty(name,Flags|BindingFlags.DeclaredOnly)?.GetValue(instance);
                if(value!=null)return value;}catch{}
            try{var value=walk.GetField(name,Flags|BindingFlags.DeclaredOnly)?.GetValue(instance);
                if(value!=null)return value;}catch{}
        }
        return null;
    }
    private static IEnumerable<object> Enumerate(object? obj)
    {
        if(obj is IEnumerable array){foreach(var x in array)if(x!=null)yield return x;yield break;}
        int count=0;try{count=Convert.ToInt32(Get(obj,"Count","Length"));}catch{}
        if(obj==null||count<1||count>60)yield break;
        var getter=obj.GetType().GetMethods(Flags).FirstOrDefault(m=>m.Name=="get_Item"&&m.GetParameters().Length==1 && m.GetParameters()[0].ParameterType==typeof(int));
        if(getter==null)yield break;
        for(var i=0;i<count;i++){
            object? element=null;try{element=getter.Invoke(obj,new object[]{i});}catch{}
            if(element!=null)yield return element;
        }
    }
    private static bool Enabled()
    {
        try{
            using var doc=JsonDocument.Parse(File.ReadAllText(At("LobbyGuardian-feature-options.json")));
            return !doc.RootElement.TryGetProperty("JoinLeaveAlertsEnabled",out var flag) || flag.ValueKind!=JsonValueKind.False;
        }catch{return true;}
    }
    private static Dictionary<string,string> Snapshot(object client,out string source)
    {
        var users=new Dictionary<string,string>(StringComparer.Ordinal);
        source="client";
        var clientList=Enumerate(Get(client,"allClients","AllClients")).Take(30).ToArray();
        if(clientList.Length>0)
        {
            var mine=Get(client,"ClientId","clientId")?.ToString();
            foreach(var data in clientList)
            {
                var id=Get(data,"Id","ClientId")?.ToString()??"";
                if(id.Length==0||id==mine)continue;
                var character=Get(data,"Character","PlayerControl","Player");
                var info=Get(character,"Data");
                var name=Get(info,"PlayerName","Name")?.ToString()??Get(data,"PlayerName","Name")?.ToString()??"";
                name=name.Trim();
                if(name.Length==0||name.Length>64)continue;
                users[id]=name;
            }
            return users;
        }
        source="player";
        var local=Get(TypeOf("PlayerControl"),"LocalPlayer");
        foreach(var player in Enumerate(Get(TypeOf("PlayerControl"),"AllPlayerControls")).Take(30))
        {
            if(ReferenceEquals(player,local))continue;
            string id=Get(player,"PlayerId")?.ToString()??"";
            string name=Get(Get(player,"Data"),"PlayerName","Name")?.ToString()?.Trim()??"";
            if(id.Length==0||name.Length==0||name.Length>64)continue;
            users[id]=name;
        }
        return users;
    }
    private static void Reset()
    {
        Current.Clear();Missing.Clear();_initialized=false;
        _room="";_source="";
    }
    private static void AddEvent(string kind,string name)
    {
        // Names come from public in-lobby labels; no account IDs or tokens are collected.
        _sequence++;
        Events.Add(new{seq=_sequence,kind,name,atUtc=DateTimeOffset.UtcNow.ToString("O")});
        if(Events.Count>40)Events.RemoveAt(0);
        Publish();
    }
    private static void Publish()
    {
        var target=At("LobbyGuardian-presence-events.json");
        var temp=target+".tmp";
        var snapshot=JsonSerializer.Serialize(new{session=InstanceId,lastSeq=_sequence,events=Events,
            notice="Only local, public join/leave activity; never transmits account information."});
        File.WriteAllText(temp,snapshot);
        File.Move(temp,target,true);
    }
    internal static void Tick()
    {
        var now=DateTimeOffset.UtcNow;
        if(now<_next)return;
        _next=now.AddMilliseconds(420);
        try
        {
            var client=GameBridge.Client;
            string state=Get(client,"GameState")?.ToString()??"";
            if(client==null||(state!="Joined"&&state!="Started")||!Enabled())
            {
                if(_initialized)Reset();
                return;
            }
            string room=Get(client,"GameId")?.ToString()??"";
            var present=Snapshot(client,out string source);
            // An empty roster is valid after the final guest leaves. Wait for three observations
            // below before reporting a leave; room/state transitions reset the baseline.
            if(!_initialized || (room.Length>0&&_room.Length>0&&room!=_room) || source!=_source)
            {
                Current.Clear();Missing.Clear();
                foreach(var player in present)Current[player.Key]=player.Value;
                _initialized=true;_room=room;_source=source;
                Publish(); // New room baseline: do not announce the players already there.
                return;
            }
            foreach(var player in present)
            {
                Missing.Remove(player.Key);
                if(!Current.ContainsKey(player.Key))AddEvent("join",player.Value);
                Current[player.Key]=player.Value; // Rename is not a new player.
            }
            foreach(var old in Current.Keys.Where(key=>!present.ContainsKey(key)).ToArray())
            {
                Missing.TryGetValue(old,out int misses);
                if(++misses<3){Missing[old]=misses;continue;}
                Missing.Remove(old);
                AddEvent("leave",Current[old]);
                Current.Remove(old);
            }
        }
        catch { /* Preserve game operation if telemetry is temporarily unavailable. */ }
    }
}
